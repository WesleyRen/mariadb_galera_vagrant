#define APSW_VERSION "3.12.2-r1"
